
package tests;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;  //    علشان اقدر اشوفها فى   test
public class LoginTest extends BaseTest{


        @Test
        //taking object from login page in valid test scenario with right  username and password
        public void testValidLogin() {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("standard_user", "secret_sauce");
            Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));
        }

        @Test
        //taking object from login page in locked user  username to check out error
        public void testLockedOutUser() {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("locked_out_user", "secret_sauce");
            Assert.assertTrue(loginPage.isErrorVisible());
            Assert.assertTrue(loginPage.getErrorMessage().toLowerCase().contains("locked"));
        }

        @Test
        public void testInvalidPassword() {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("standard_user", "wrong_pass");
            Assert.assertTrue(loginPage.isErrorVisible());
            Assert.assertTrue(loginPage.getErrorMessage().contains("Username and password do not match"));
        }

        @Test
        //taking object from login page in empty username and password
        public void testEmptyUsernameAndPassword() {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("", "");
            Assert.assertTrue(loginPage.isErrorVisible());
            Assert.assertTrue(loginPage.getErrorMessage().contains("Username is required"));
        }

        @Test

        public void testInvalidUsername() {
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("fake_user", "secret_sauce");
            Assert.assertTrue(loginPage.isErrorVisible());



        }
    }


