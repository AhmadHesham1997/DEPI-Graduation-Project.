
package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

public class CartAndCheckoutTest extends BaseTest {

    @Test
    public void testAddToCartAndCheckoutSuccess() {
        // تسجيل دخول
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("standard_user", "secret_sauce");

        // إضافة منتج
        InventoryPage inventoryPage = new InventoryPage(driver);
        inventoryPage.addFirstProductToCart();
        inventoryPage.goToCart();

        // تحقق من وجود المنتج في السلة
        CartPage cartPage = new CartPage(driver);
        //Assert.assertTrue(cartPage.isProductInCart(), "المنتج غير موجود في السلة");

        // متابعة الدفع
        cartPage.clickCheckout();
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.fillInformation("ahmed", "ahmed", "1234");
        checkoutPage.finishCheckout();

        // تحقق من نجاح الطلب
        Assert.assertTrue(checkoutPage.isThankYouVisible(), "  Thank you for your order!");
    }
}
