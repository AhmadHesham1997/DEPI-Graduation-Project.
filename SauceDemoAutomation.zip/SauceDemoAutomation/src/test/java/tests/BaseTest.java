package tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
public class BaseTest {
// عرفنا ال driver  بحيث يكون global  علشان يتشاف على مستوى ال class  كله
        protected WebDriver driver;

        @BeforeMethod
        public void setUp() {
            driver = new ChromeDriver();//take object
            driver.manage().window().maximize();
            driver.get("https://www.saucedemo.com/");
        }

        @AfterMethod
        public void tearDown() {
            driver.quit();
        }
    }


