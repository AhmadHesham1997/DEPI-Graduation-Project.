package pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
public class InventoryPage {

        WebDriver driver;
//page locator
        @FindBy(css = ".inventory_item:first-of-type .btn_inventory")
        WebElement firstAddToCartBtn;

        @FindBy(css = ".shopping_cart_link")
        WebElement cartIcon;

        public InventoryPage(WebDriver driver) {
            this.driver = driver;
            PageFactory.initElements(driver, this);
        }

        public void addFirstProductToCart() {
            firstAddToCartBtn.click();
        }

        public void goToCart() {
            cartIcon.click();
        }
    }


