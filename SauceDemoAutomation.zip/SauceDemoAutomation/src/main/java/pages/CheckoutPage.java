package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class CheckoutPage {
    WebDriver driver;

    @FindBy(id = "first-name")
    WebElement firstNameInput;

    @FindBy(id = "last-name")
    WebElement lastNameInput;

    @FindBy(id = "postal-code")
    WebElement postalCodeInput;

    @FindBy(id = "continue")
    WebElement continueButton;

    @FindBy(id = "finish")
    WebElement finishButton;

    @FindBy(css = ".complete-header")
    WebElement thankYouMessage;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillInformation(String first, String last, String zip) {
        firstNameInput.sendKeys(first);
        lastNameInput.sendKeys(last);
        postalCodeInput.sendKeys(zip);
        continueButton.click();
    }

    public void finishCheckout() {
        finishButton.click();
    }

    public boolean isThankYouVisible() {
        return thankYouMessage.isDisplayed();
    }
}
